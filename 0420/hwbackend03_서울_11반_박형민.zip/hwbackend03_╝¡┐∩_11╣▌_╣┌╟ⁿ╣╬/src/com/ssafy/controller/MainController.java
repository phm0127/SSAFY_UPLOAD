package com.ssafy.controller;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.model.MemberDto;
import com.ssafy.model.ProductDto;
import com.ssafy.model.service.LoginService;
import com.ssafy.model.service.LoginServiceImpl;
import com.ssafy.model.service.ProductService;
import com.ssafy.model.service.ProductServiceImpl;


@WebServlet("/main.do")
public class MainController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private LoginService loginService;
	private ProductService productService;

	public void init() {

		loginService = new LoginServiceImpl();
		productService = new ProductServiceImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//mvjoin, list
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//login, write
		request.setCharacterEncoding("utf-8");
		process(request, response);
	}

	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String root = request.getContextPath();
		String act = request.getParameter("act");
		System.out.println(act);
		String path = "/index.jsp";
		if("mvjoin".equals(act)) {
			path = "/user/join.jsp";
			response.sendRedirect(root+path);
		}else if("login".equals(act)) {
			login(request, response);
		}else if("list".equals(act)) {
			path = "/product/list.jsp";
			List<ProductDto> list=null;
			try {
				list = productService.getProductList();
				request.setAttribute("products", list);
				RequestDispatcher dispatcher = request.getRequestDispatcher(path);
				dispatcher.forward(request, response);
			} catch (Exception e) {
				response.sendRedirect("/hw/product/writefail.jsp");
				e.printStackTrace();
			}

		}else if("last".equals(act)) {
			path = "/product/writesuccess.jsp";
			
			Cookie[] cookies = request.getCookies();
			String name =null;
			for(int i=0;i<cookies.length;i++) {
				if(cookies[i]!=null&&cookies[i].getName().equals("last")) {
					name= URLDecoder.decode(cookies[0].getValue(), "UTF-8");
					break;
				}
			}
			try {
				if(name==null) {
					throw new Exception();
				}
				ProductDto productDto = productService.getProduct(name.trim());
				//System.out.println(">"+productDto.getProductName());
				request.setAttribute("product", productDto);
				request.setAttribute("msg", "마지막 등록한 상품");
				RequestDispatcher dispatcher = request.getRequestDispatcher(path);
				dispatcher.forward(request, response);
			} catch (Exception e) {
				response.sendRedirect("/hw/product/writefail.jsp");
				e.printStackTrace();
			}

		}else if("write".equals(act)) {
			path = "/product/writesuccess.jsp";
			ProductDto productDto = new ProductDto(request.getParameter("productname"), Integer.parseInt(request.getParameter("price")),request.getParameter("description"));
			try {
				int cnt = productService.insertProduct(productDto);
				if(cnt != 0) {
					ProductDto productDTO = new ProductDto( productDto.getProductName(), productDto.getPrice(), productDto.getDescription());
					request.setAttribute("product", productDTO);
					String productname = URLEncoder.encode(productDto.getProductName(), "UTF-8");
					Cookie[] cookies = request.getCookies();
					for(int i=0;i<cookies.length;i++) {
						cookies[i].setMaxAge(0);
						response.addCookie(cookies[i]);
					}
					Cookie cookie = new Cookie("last",productname );
					response.addCookie(cookie);
					RequestDispatcher dispatcher = request.getRequestDispatcher(path);
					dispatcher.forward(request, response);
				} else {
					response.sendRedirect("/hw/product/writefail.jsp");
				}
			} catch (Exception e) {
				response.sendRedirect("/hw/product/writefail.jsp");
				e.printStackTrace();
			}

		}else if("remove".equals(act)) {
			int productNo = Integer.parseInt(request.getParameter("no"));
			try {
				productService.removeProduct(productNo);
				path = "/product/list.jsp";
				List<ProductDto> list=null;
				try {
					list = productService.getProductList();
					request.setAttribute("products", list);
					RequestDispatcher dispatcher = request.getRequestDispatcher(path);
					dispatcher.forward(request, response);
				} catch (Exception e) {
					response.sendRedirect("/hw/product/writefail.jsp");
					e.printStackTrace();
				}
			} catch (Exception e) {
				response.sendRedirect("/hw/product/writefail.jsp");
				e.printStackTrace();
			}

		}else if("modify".equals(act)) {
			path = "/productModify.jsp";
			int productNo = Integer.parseInt(request.getParameter("no"));
			ProductDto productDto = null;
			try {
				productDto = productService.getProduct(productNo);
				request.setAttribute("product", productDto);
				RequestDispatcher dispatcher = request.getRequestDispatcher(path);
				dispatcher.forward(request, response);

			} catch (Exception e) {
				response.sendRedirect("/hw/product/writefail.jsp");
				e.printStackTrace();
			}

		}else if("save".equals(act)) {
			path = "/product/writesuccess.jsp";
			//int productNo = (int)request.getAttribute("no");
			int productNo = Integer.parseInt(request.getParameter("no"));
			ProductDto productDto = new ProductDto(request.getParameter("productname"), Integer.parseInt(request.getParameter("price")),request.getParameter("description"));
			try {
				int ret = productService.updateProduct(productNo, productDto);
				if(ret>0) {
					request.setAttribute("product", productDto);
					RequestDispatcher dispatcher = request.getRequestDispatcher(path);
					dispatcher.forward(request, response);
				}
				else {
					response.sendRedirect("/hw/product/writefail.jsp");
				}

			} catch (Exception e) {
				response.sendRedirect("/hw/product/writefail.jsp");
				e.printStackTrace();
			}


		}
		else {
			System.out.println("?"+act);
			System.out.println("no!!");
		}
	}

	private void deleteArticle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";

	}

	private void modifyArticle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";


	}

	private void moveModifyArticle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";

	}

	private void listArticle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";

	}

	private void writeArticle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";

	}

	private void logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String path = "/index.jsp";

	}

	private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		String userid = request.getParameter("userid");
		String userpwd = request.getParameter("userpwd");
		System.out.println(userid+"/"+userpwd);
		try {
			MemberDto memberDto = loginService.login(userid, userpwd);
			if(memberDto!=null) {
				HttpSession session = request.getSession();
				session.setAttribute("userinfo", memberDto);
				path="/index.jsp";
			}else {
				request.setAttribute("msg", "아이디 또는 비밀번호를 확인 해 주세요.");
				path="/index.jsp";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.getRequestDispatcher(path).forward(request, response);;
	}



}
