package com.ssafy.model.dao;

import java.util.List;

import com.ssafy.model.ProductDto;

public interface ProductDao {
	
	
	public int insertProduct(ProductDto productDto) throws Exception;
	
	public List<ProductDto> getProductList() throws Exception;
	
	public ProductDto getProduct(String name) throws Exception;
	
	public ProductDto getProduct(int no) throws Exception;
	
	public int updateProduct(int productNo,ProductDto productDto) throws Exception;
	
	public int removeProduct(int productNo) throws Exception;
}
