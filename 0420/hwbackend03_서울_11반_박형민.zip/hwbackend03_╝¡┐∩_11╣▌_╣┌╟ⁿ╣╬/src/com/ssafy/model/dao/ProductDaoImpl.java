package com.ssafy.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.model.MemberDto;
import com.ssafy.model.ProductDto;
import com.ssafy.util.DBUtil;

public class ProductDaoImpl implements ProductDao{

	@Override
	public int insertProduct(ProductDto productDto) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int ret=-1;
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("insert into product (productname, price, description, regtime) \n");
			sql.append("values (?, ?, ?, now())");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, productDto.getProductName());
			pstmt.setInt(2, productDto.getPrice());
			pstmt.setString(3, productDto.getDescription());
			ret = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null)
					pstmt.close();
				if(conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return ret;
	}

	@Override
	public List<ProductDto> getProductList() throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<ProductDto> list = new ArrayList<ProductDto>();
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select productno, productname, price, description, regtime \n");
			sql.append("from product \n");
			sql.append("order by productno desc \n");
			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while(rs.next()) {
				ProductDto product = new ProductDto(rs.getInt("productno"), rs.getString("productname"),rs.getInt("price") ,rs.getString("description"), rs.getString("regtime"));
				list.add(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null)
					rs.close();
				if(pstmt != null)
					pstmt.close();
				if(conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	@Override
	public ProductDto getProduct(String name) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProductDto product=null;
		List<ProductDto> list = new ArrayList<ProductDto>();
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select productno, productname, price, description, regtime \n");
			sql.append("from product \n");
			sql.append("where productname= ? \n");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				product = new ProductDto(rs.getInt("productno"), rs.getString("productname"),rs.getInt("price") ,rs.getString("description"), rs.getString("regtime"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null)
					rs.close();
				if(pstmt != null)
					pstmt.close();
				if(conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return product;
	}

	@Override
	public int removeProduct(int productNo) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int ret=-1;
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("delete from product \n");
			sql.append("where productno = ?");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, productNo);
			ret = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null)
					pstmt.close();
				if(conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return ret;
	}

	@Override
	public ProductDto getProduct(int no) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProductDto product=null;
		List<ProductDto> list = new ArrayList<ProductDto>();
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select productno, productname, price, description, regtime \n");
			sql.append("from product \n");
			sql.append("where productno= ? \n");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				product = new ProductDto(rs.getInt("productno"), rs.getString("productname"),rs.getInt("price") ,rs.getString("description"), rs.getString("regtime"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null)
					rs.close();
				if(pstmt != null)
					pstmt.close();
				if(conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return product;
	}

	@Override
	public int updateProduct(int productNo, ProductDto productDto) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProductDto product=null;
		List<ProductDto> list = new ArrayList<ProductDto>();
		int ret=-1;
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("update product \n");
			sql.append("set productname = ? ");
			sql.append(", price = ? ");
			sql.append(", description = ? \n");
			sql.append("where productno= ? \n");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, productDto.getProductName());
			pstmt.setInt(2, productDto.getPrice());
			pstmt.setString(3, productDto.getDescription());
			pstmt.setInt(4, productNo);
			ret = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null)
					rs.close();
				if(pstmt != null)
					pstmt.close();
				if(conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return ret;
	}

}
