package com.ssafy.model.service;

import java.util.List;

import com.ssafy.model.ProductDto;
import com.ssafy.model.dao.ProductDao;
import com.ssafy.model.dao.ProductDaoImpl;

public class ProductServiceImpl implements ProductService{
	ProductDao productDao;
	public ProductServiceImpl() {
		productDao = new ProductDaoImpl();
	}
	@Override
	public int insertProduct(ProductDto productDto) throws Exception {
		return productDao.insertProduct(productDto);
	}

	@Override
	public List<ProductDto> getProductList() throws Exception {
		return productDao.getProductList();
	}

	@Override
	public ProductDto getProduct(String name) throws Exception {
		return productDao.getProduct(name);
	}
	@Override
	public int removeProduct(int productNo) throws Exception {
		return productDao.removeProduct(productNo);
	}
	@Override
	public ProductDto getProduct(int no) throws Exception {
		return productDao.getProduct(no);
	}
	@Override
	public int updateProduct(int productNo, ProductDto productDto) throws Exception {
		return productDao.updateProduct(productNo, productDto);
	}

}
