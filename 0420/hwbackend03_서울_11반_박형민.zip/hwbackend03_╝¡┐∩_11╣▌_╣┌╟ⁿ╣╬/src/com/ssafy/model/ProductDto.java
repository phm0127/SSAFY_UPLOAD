package com.ssafy.model;

public class ProductDto {
	private int productNo;
	private String productName;
	private int price;
	private String description;
	private String regTime;
	
	public ProductDto() {
		
	}
	public ProductDto(int productNo, String productName, int price, String description, String regTime) {
		this.productNo = productNo;
		this.productName = productName;
		this.price = price;
		this.description = description;
		this.regTime = regTime;
	}
	
	public ProductDto(String productName, int price, String description) {
		this.productName = productName;
		this.price = price;
		this.description = description;
	}
	
	public int getProductNo() {
		return productNo;
	}
	public void setProductNo(int productNo) {
		this.productNo = productNo;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRegTime() {
		return regTime;
	}
	public void setRegTime(String regTime) {
		this.regTime = regTime;
	}
	
}
