import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    count : 0
  },
  mutations: {},
  actions: {},
  getters : {
    countMsg(state) {
     
      let msg;
      if (state.count == 0) {
        msg= '검색 결과가 없습니다. ';
      } else {
        msg = state.count+'명의 검색 결과를 찾았습니다.';
      }
      return msg;
    },
  }
});
