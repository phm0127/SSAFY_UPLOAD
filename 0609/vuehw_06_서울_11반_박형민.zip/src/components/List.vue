<template>
   <div >
    <h2 style="text-align: center;">사원 목록</h2>
    <input type="text" id="search" v-model="search" style="width: 50%; margin: 10px auto;">
    <p>{{countMsg}}</p>
    <table style=" border: 1px solid #444444;
    border-collapse: collapse; ">
        <colgroup>

            <col style="width: 8%; " />

            <col style="width: 8%;" />

            <col style="width: 8%;" />

            <col style="width: 8%;" />

            <col style="width: 8%;" />

        </colgroup>
        <tr style="background: #4270c2;
    border: 1px solid #d1d1d1;
    color: #eeeeee;">
            <th>
                사원 아이디
            </th>
            <th>
                사원명
            </th>
            <th>
                부서
            </th>
            <th>
                직책
            </th>
            <th>
                연봉
            </th>
        </tr>
        <template v-for="emp in emplist">
            <tr style="text-align: center;" v-show="emp.name.includes(search)&&search.length!==0" v-bind:key="emp">
                <td>
                    {{emp.no}}
                </td>
                <td>
                    {{emp.name}}
                </td>
                <td>
                    {{emp.depart}}
                </td>
                <td>
                    {{emp.position}}
                </td>
                <td>
                    {{emp.salary}}
                </td>
            </tr>
        </template>
    </table>

</div>
</template>

<script>
import axios from 'axios';
import {mapGetters} from 'vuex';

export default {
     computed: {
        ...mapGetters(['countMsg']),
        
     },
    name: 'List',
    data: function() {

        return {
            show: true,
            search: '',
            emplist: []
        }
    }//data
    , created() {
        axios({
            url: 'http://localhost:8080/vue/employee/',
            method: 'get'
        })//axios
            .then((response) => {
                console.dir(response.data)
                this.emplist = response.data;
            })//then
            .catch((error) => {
                console.dir(error);
            });//catch
       

    }//created
}
</script>

<style>

</style>