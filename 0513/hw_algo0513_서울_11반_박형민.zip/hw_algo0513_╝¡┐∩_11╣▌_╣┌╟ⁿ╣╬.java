import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class hw_algo0513_서울_11반_박형민 {
	public static void main(String[] args) throws IOException {
		int N,M;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine(), " ");
		
		N = Integer.parseInt(st.nextToken()); 
		M = Integer.parseInt(st.nextToken()); 
		int[] degree=new int[N];
		ArrayList<Integer>[] list = new ArrayList[N];
		for(int i=0;i<N;i++) {
			list[i]=new ArrayList<Integer>();
		}
		for(int i=0;i<M;i++) {
			st = new StringTokenizer(br.readLine(), " ");
			int from = Integer.parseInt(st.nextToken())-1;
			int end = Integer.parseInt(st.nextToken())-1;
			list[from].add(end);
			degree[end]++;
		}
		Queue<Integer> q = new LinkedList<Integer>();
		for(int i=0;i<N;i++) {
			if(degree[i]==0) {
				q.add(i);
			}
		}
		Iterator<Integer> iter;
		while(!q.isEmpty()) {
			int pos = q.poll();
			System.out.print((pos+1)+" ");
			iter=list[pos].iterator();
			while(iter.hasNext()) {
				int i = iter.next();
				degree[i]--;
				if(degree[i]==0) {
					q.add(i);
					iter.remove();
				}
			}
		}
		
	}

}
