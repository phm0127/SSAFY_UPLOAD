import java.util.Arrays;
import java.util.Scanner;

public class Solution_6719 {
	static int N,K;
	static float answer;
	static int[] M,arr;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int TC = sc.nextInt();
		for(int test_case =1 ; test_case<=TC;test_case++) {
			answer=0;
			N = sc.nextInt();
			K = sc.nextInt();
			M = new int[N];
			arr = new int[K];
			for(int i = 0; i<N;i++) {
				M[i] = sc.nextInt();
			}
			Arrays.sort(M);
			for(int i=N-K;i<N;i++) {
				answer+=M[i];
				answer/=2;
			}
			
			
			System.out.printf("#%d %.6f\n",test_case,answer);
		}
	}

}
