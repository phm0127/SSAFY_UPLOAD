import java.util.Scanner;

public class Solution_6782 {
	static long N,answer;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int TC = sc.nextInt();
		for(int test_case =1 ;test_case<=TC;test_case++) {
			answer = 0;
			N = sc.nextLong();
			while(true) {
				if(N==2) {
					break;
				}
				if(N<2) {
					continue;
				}
				Double sqrt = Math.sqrt(N);
				if(sqrt==sqrt.longValue()) {
					N=(sqrt.longValue());
				}
				else {
					answer+=(sqrt.longValue()+1)*(sqrt.longValue()+1)-N;
					N=(sqrt.longValue()+1);
				}
				answer++;
			}

		System.out.println("#"+test_case+" "+answer);
	}
}

}
