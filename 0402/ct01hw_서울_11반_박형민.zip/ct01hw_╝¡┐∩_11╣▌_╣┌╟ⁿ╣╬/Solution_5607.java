import java.util.Scanner;

public class Solution_5607 {
    public static void main(String[] ar){
        Scanner sc = new Scanner(System.in);
        int TC = sc.nextInt();
        final long p = 1234567891;
        for(int test_case = 1; test_case<=TC;test_case++) {
        	int N = sc.nextInt();
        	int K = sc.nextInt();
        	long[] factorial = new long[N+1];        	
        	factorial[0] = 1;
        	factorial[1] = 1;
        	for(int i=2; i<=N; i++) {
        			factorial[i] = (factorial[i-1]*i)%p;
        	}
        	long lower = (factorial[K]*factorial[N-K])%p;
        	long index = p-2;
        	long fermatNum = 1;
        	while(index > 0){
        		if(index%2==1){
        			fermatNum *= lower;
        			fermatNum %= p;
        		}
        		lower = (lower*lower)%p;
        		index /= 2;
        	}
        	long result = ((factorial[N]%p)*(fermatNum%p))%p;
        	System.out.print("#"+test_case+" "+result);
        }
    }
}