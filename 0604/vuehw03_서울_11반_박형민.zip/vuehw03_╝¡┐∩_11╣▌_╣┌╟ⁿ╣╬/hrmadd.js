import { vm, addBtn} from './hrmadd_module.js';
