var vl = new Vue({
    el: "#table",
    data: {
        show: true,
        search: '',
        emplist: [

        ]
    },
    created() {
        const employee = JSON.parse(localStorage.getItem('emplist'));
        this.emplist = employee;
    }
})


export { vl };