let vm = new Vue({
    el: "#emp",
    data: {
        name: '',
        email: '',
        hiredate: '',
        admin: false,
        admins: [
            {
                admin: true,
                showtext: "권한 있음"
            },
            {
                admin: false,
                showtext: "권한 없음"
            }
        ],
        position: '사장',
        positions: [
            {
                position: '사장'
            },
            {
                position: '기획부장'
            },
            {
                position: '영업부장'
            },
            {
                position: '총무부장'
            },

            {
                position: '인사부장'
            },
            {
                position: '과장'
            },
            {
                position: '영업대표이사'
            },
            {
                position: '사원'
            }
        ],
        depart: '기획부',
        departs: [
            {
                depart: '기획부'
            },
            {
                depart: '영업부'
            },
            {
                depart: '총무부'
            },
            {
                depart: '인사부'
            },
            {
                depart: '기타'
            }
        ],
        salary: '',
        commission: ''
    }

});
let addBtn = document.querySelector("#addBtn");
addBtn.onclick = function () {
    let emplist = JSON.parse(localStorage.getItem('emplist'));
    let employee = { id: localStorage.length, name: vm.name, email: vm.email, hiredate: vm.hiredate, admin: vm.admin, position: vm.position, depart: vm.depart, salary: vm.salary, commission: vm.commission };
    if (emplist == null) {
        emplist = [];
    }
    emplist.push(employee);
    localStorage.setItem('emplist', JSON.stringify(emplist));
    console.log(emplist);

};


export {vm,addBtn};