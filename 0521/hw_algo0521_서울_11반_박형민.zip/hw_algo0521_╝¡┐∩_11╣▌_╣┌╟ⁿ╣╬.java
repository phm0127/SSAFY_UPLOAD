import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class hw_algo0521_서울_11반_박형민 {
	static int N,K;
	static String[] srr;
	static char[] pick= {'a','n','t','i','c'};
	static char[] alphabet= {'b','d','e','f','g','h','j','k','l','m','o','p','q','r','s','u','v','w','x','y','z'};
	static int answer;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		K = sc.nextInt();
		srr= new String[N];
		for(int i=0;i<N;i++) {
			srr[i]=sc.next();
		}
		Set<Character> set = new HashSet<>();
		for(int i=0;i<5;i++) {
			set.add(pick[i]);
		}
		dp(0,set,0);
		System.out.println(answer);
		
	}
	public static void dp(int index,Set<Character> set, int cnt) {
		if(cnt==K-5) {
			answer=Math.max(answer, cal(set));
			return;
		}
		if(index>=alphabet.length) {
			return;
		}
		
		dp(index+1,set,cnt);
		set.add(alphabet[index]);
		dp(index+1,set,cnt+1);
		set.remove(alphabet[index]);
	}
	
	public static int cal(Set<Character> set) {
		int ret=0;
		for(int i=0;i<N;i++) {
			boolean flag = true;
			for(int j=0;j<srr[i].length();j++) {
				if(!set.contains(srr[i].charAt(j))) {
					flag=false;
					break;
				}
			}
			if(flag) ret++;
		}
		return ret;
	}
}
