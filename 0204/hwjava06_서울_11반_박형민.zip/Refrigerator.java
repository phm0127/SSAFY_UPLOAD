package com.ssafy.java;

public class Refrigerator extends Product{
	public String toString() {
		String str=serial+"	|"+name+"	|"+price+"	|"+stock+"	|"+size;
		return str;
	}
}
