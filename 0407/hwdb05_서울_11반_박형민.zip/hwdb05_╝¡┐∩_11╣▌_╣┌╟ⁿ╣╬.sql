use scott;

-- 1
select a.ename, a.job, a.sal
from emp a inner join dept b on a.deptno = b.deptno
where b.loc = 'CHICAGO';

-- 2
select empno, ename, job, deptno
from emp 
where empno not in
(select b.empno
from emp a join emp b on a.mgr = b.empno);

-- 3
select a.ename, a.job, a.MGR
from emp a join emp b on a.mgr = b.empno
where a.mgr =
(select mgr
from emp 
where ename="BLAKE");

-- 4
select *
from emp
order by hiredate limit 5;


-- 5
select ename, job, dname
from emp join dept on emp.DEPTNO=dept.DEPTNO
where empno in
(select a.empno
from emp a join emp b on a.mgr = b.empno
where b.empno =
(select empno
from emp
where ename = "JONES"));




