create database if not exists ssafyvue;

use ssafyvue;
-- drop table vue_employee;

CREATE TABLE `vue_employee` (
  `no` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) ,
  `email` varchar(30) ,
  `hiredate` timestamp DEFAULT CURRENT_TIMESTAMP,
  `admin` varchar(20) ,
  `position` varchar(20) ,
  `depart` varchar(20) ,
  `salary` int ,
  `commission` int ,
  PRIMARY KEY (`no`)
);

insert into vue_employee (name, email,hiredate,admin,position,depart,salary,commission) 
values('김갑을', 'gab@naver.com', '2017.01.11','관리자','기획 부장','기획부', 1000,500);
insert into vue_employee (name, email,hiredate,admin,position,depart,salary,commission) 
values('나천재', 'genius@daum.net', '2019.10.04','관리자','사원','인사부', 1000,500);
insert into vue_employee ( name, email,hiredate,admin,position,depart,salary,commission) 
values('고 수', 'gosu@gmail.com', '2018.08.22','관리자','사장','총무부', 1000,500);
insert into vue_employee (name, email,hiredate,admin,position,depart,salary,commission) 
values('박과장', 'gwajang@yahoo.com', '2020.05.31','관리자','과장','영업부', 1000,500);
commit;

select * from vue_employee;