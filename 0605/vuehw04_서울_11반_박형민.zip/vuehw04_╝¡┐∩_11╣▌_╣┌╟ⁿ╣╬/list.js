
const Main = {
    template: `<div id="emp">
    <table style="width: 60%; border: 1px solid #f5f5f5; border-collapse: separate; ">
        <colgroup>

            <col style="width: 8%;  " />

            <col style="width: 8%;" />



        </colgroup>
        <tr>
            <td style="background-color: #4270c2; color: #f5f5f5; text-align:center; padding: 5px;">
                이름
            </td>
            <td style="padding: 5px 10px;">
                <input type="text" id="name" v-model="name">
            </td>
        </tr>
        <tr>
            <td style="background-color: #4270c2; color: #f5f5f5; text-align:center; padding: 5px;">
                이메일
            </td>
            <td style="padding: 5px 10px;">
                <input type="text" id="email" v-model="email">
            </td>
        </tr>
        <tr>
            <td style="background-color: #4270c2; color: #f5f5f5; text-align:center; padding: 5px;">
                고용일
            </td>
            <td style="padding: 5px 10px;">
                <input type="date" id="hiredate" v-model="hiredate">
            </td>
        </tr>
        <tr>
            <td style="background-color: #4270c2; color: #f5f5f5; text-align:center; padding: 5px;">
                관리자
            </td>
            <td style="padding: 5px 10px;">
                <select id="admin" v-model="admin" style="padding: 5px 10px;">
                    <option :value=adm.admin v-for="adm in admins">{{adm.showtext}}</option>
                </select>
            </td>
        </tr>
        <tr>
            <td style="background-color: #4270c2; color: #f5f5f5; text-align:center; padding: 5px;">
                직책
            </td>
            <td style="padding: 5px 10px;">
                <select id="position" v-model="position" style="padding: 5px 10px;">
                    <option :value=pos.position v-for="pos in positions">{{pos.position}}</option>
                </select>
            </td>
        </tr>
        <tr>
            <td style="background-color: #4270c2; color: #f5f5f5; text-align:center; padding: 5px;">
                부서
            </td>
            <td style="padding: 5px 10px;">
                <select id="depart" v-model="depart" style="padding: 5px 10px;">
                    <option :value=dep.depart v-for="dep in departs">{{dep.depart}}</option>
                </select>

            </td>
        </tr>
        <tr>
            <td style="background-color: #4270c2; color: #f5f5f5; text-align:center; padding: 5px;">
                월급
            </td>
            <td style="padding: 5px 10px;">
                <input type="number" id="salary" v-model="salary">
            </td>
        </tr>
        <tr>
            <td style="background-color: #4270c2; color: #f5f5f5; text-align:center; padding: 5px;">
                커미션
            </td>
            <td style="padding: 5px 10px;">
                <input type="number" id="commission" v-model="commission">
            </td>
        </tr>
    </table>
    <button id="addBtn" v-on:click="clickBtn()" style="display: table; margin : 10px auto;">사원 추가</button>

</div>`
    , data() {

        return {
            name: '',
            email: '',
            hiredate: '',
            admin: false,
            admins: [
                {
                    admin: true,
                    showtext: "권한 있음"
                },
                {
                    admin: false,
                    showtext: "권한 없음"
                }
            ],
            position: '사장',
            positions: [
                {
                    position: '사장'
                },
                {
                    position: '기획부장'
                },
                {
                    position: '영업부장'
                },
                {
                    position: '총무부장'
                },

                {
                    position: '인사부장'
                },
                {
                    position: '과장'
                },
                {
                    position: '영업대표이사'
                },
                {
                    position: '사원'
                }
            ],
            depart: '기획부',
            departs: [
                {
                    depart: '기획부'
                },
                {
                    depart: '영업부'
                },
                {
                    depart: '총무부'
                },
                {
                    depart: '인사부'
                },
                {
                    depart: '기타'
                }
            ],
            salary: '',
            commission: ''
        }
    }//data
	
	
    , created() {
        




    }//created
    , methods : {
		clickBtn() {
        	console.log("hi");
            let employee = {name: this.name, email: this.email, hiredate: this.hiredate, admin: this.admin, position: this.position, depart: this.depart, salary: this.salary, commission: this.commission };
            console.log(this.name);
            axios({
                url: 'http://localhost:8080/vue/employee/',
                method: 'post',
                data:{
                	name: this.name, email: this.email, hiredate: this.hiredate, admin: this.admin, position: this.position, depart: this.depart, salary: this.salary, commission: this.commission
                }
            })//axios
                .then((response) => {
                    console.dir(response.data)
                   
                })//then
                .catch((error) => {
                    console.dir(error);
                });//catch
            console.log(employee);

        }
	}
};




const List = {
    template: `<div >
    <h2 style="text-align: center;">사원 목록</h2>
    <input type="text" id="search" v-model="search" style="width: 50%; margin: 10px auto;">

    <table style=" border: 1px solid #444444;
    border-collapse: collapse; ">
        <colgroup>

            <col style="width: 8%; " />

            <col style="width: 8%;" />

            <col style="width: 8%;" />

            <col style="width: 8%;" />

            <col style="width: 8%;" />

        </colgroup>
        <tr style="background: #4270c2;
    border: 1px solid #d1d1d1;
    color: #eeeeee;">
            <th>
                사원 아이디
            </th>
            <th>
                사원명
            </th>
            <th>
                부서
            </th>
            <th>
                직책
            </th>
            <th>
                연봉
            </th>
        </tr>
        <template v-for="emp in emplist">
            <tr style="text-align: center;" v-show="emp.name.includes(search)&&search.length!==0">
                <td>
                    {{emp.no}}
                </td>
                <td>
                    {{emp.name}}
                </td>
                <td>
                    {{emp.depart}}
                </td>
                <td>
                    {{emp.position}}
                </td>
                <td>
                    {{emp.salary}}
                </td>
            </tr>
        </template>
    </table>

</div>

`
    , data() {

        return {
            show: true,
            search: '',
            emplist: []
        }
    }//data
    , created() {
        axios({
            url: 'http://localhost:8080/vue/employee/',
            method: 'get'
        })//axios
            .then((response) => {
                console.dir(response.data)
                this.emplist = response.data;
            })//then
            .catch((error) => {
                console.dir(error);
            });//catch
       

    }//created
};




const router = new VueRouter({

    routes: [
        {
            path: '/',
            name: 'main',
            component: Main,
        },
        {
            path: '/list',
            name: 'list',
            component: List,

        },
    ],
});
// Vue 인스턴트 라우터 주입
new Vue({
    el: '#app',
    router: router,
});
