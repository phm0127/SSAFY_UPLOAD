import java.util.Scanner;

public class hw_algo0522_서울_11반_박형민 {
	
	static int answer;
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int TC = sc.nextInt();
		for(int test_case =1 ; test_case<=TC;test_case++) {
			answer=0;
			int N = sc.nextInt();
			int[] arr=new int[N];
			boolean[] b= new boolean[N];
			for(int i=0;i<N;i++) {
				arr[i]=sc.nextInt();
			}
			dfs(0,0,0,arr,b);
			System.out.println("#"+test_case+" "+answer);
		}
	}
	
	public static void dfs(int index,int right, int left,int[] arr,boolean[] b) {
		if(index==arr.length) {
			answer++;
			return;
		}
		for(int i=0;i<arr.length;i++) {
			if(!b[i]) {
				b[i]=true;
				if(right+arr[i]<=left) {
					dfs(index+1,right+arr[i],left,arr,b);
				}
				dfs(index+1,right,left+arr[i],arr,b);
				b[i]=false;
			}
		}
	}
	

}
