package com.ssafy.product;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/product.do")
public class ProductTest extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	@Override
	public void init() throws ServletException {
		super.init();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		//1. data get
		String productName = request.getParameter("productname");
		int price= Integer.parseInt(request.getParameter("price"));
		String description = request.getParameter("description");

		//2. logic
		Connection conn = null;
		PreparedStatement pstmt = null;
		int cnt = 0;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ssafyproduct?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8", "ssafy", "ssafy");
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("insert into product (productname, price, description, regtime) \n");
			insertMember.append("values (?, ?, ?, now())");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setString(1, productName);
			pstmt.setInt(2, price);
			pstmt.setString(3, description);
			cnt = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null)
					pstmt.close();
				if(conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
		if(cnt != 0) {
			ProductDTO productDTO = new ProductDTO( productName, price, description);
			request.setAttribute("product", productDTO);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/product/writesuccess.jsp");
			dispatcher.forward(request, response);
		} else {
			response.sendRedirect("/hw/product/writefail.jsp");
		}

		//3. response page
		
	}

}
