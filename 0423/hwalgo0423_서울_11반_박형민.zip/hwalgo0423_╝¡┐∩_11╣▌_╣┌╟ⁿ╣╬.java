import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class hwalgo0423_서울_11반_박형민 {
	static int N,L,R;
	static int answer;
	static int[][] A;
	static boolean[][] b;
	static int[] dR = {-1,1,0,0};
	static int[] dC = {0,0,-1,1};
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N=sc.nextInt();
		L=sc.nextInt();
		R=sc.nextInt();
		A = new int[N][N];
		for(int i=0;i<N;i++) {
			for(int j=0;j<N;j++) {
				A[i][j] = sc.nextInt();
			}
		}
		
		cal(0);
		
		
		System.out.println(answer);
	}
	
	public static void cal(int day) {
		if(day>2000) {
			return;
		}
		boolean flag = false;
		Queue<Point> q = new LinkedList<Point>();
		Queue<Point> plus = new LinkedList<Point>();
		b = new boolean[N][N];
		for(int i=0;i<N;i++) {
			for(int j=0;j<N;j++) {
				if(b[i][j]) {
					continue;
				}
				b[i][j]=true;
				q.add(new Point(i,j));
				plus.add(new Point(i,j));
				int r,c,nr,nc,num=A[i][j],count=1;
				while(!q.isEmpty()) {
					Point p = q.poll();
					r=p.r;
					c=p.c;
					for(int k=0;k<4;k++) {
						nr=r+dR[k];
						nc=c+dC[k];
						if(nr<0||nc<0||nr>=N||nc>=N||Math.abs(A[r][c]-A[nr][nc])<L||Math.abs(A[r][c]-A[nr][nc])>R) {
							continue;
						}
						if(!b[nr][nc]) {
							b[nr][nc]=true;
							q.add(new Point(nr,nc));
							plus.add(new Point(nr,nc));
							count++;
							num+=A[nr][nc];
						}
					}
					
				}
				num/=count;
				if(plus.size()>1) {
					flag=true;
				}
				while(!plus.isEmpty()) {
					Point p = plus.poll();
					r=p.r;
					c=p.c;
					A[r][c]=num;
				}
			}
		}
		
		if(flag) {
			cal(day+1);
		}else {
			answer=day;
		}
		
	}

}

class Point{
	int r;
	int c;
	Point(int r, int c){
		this.r=r;
		this.c=c;
	}
}