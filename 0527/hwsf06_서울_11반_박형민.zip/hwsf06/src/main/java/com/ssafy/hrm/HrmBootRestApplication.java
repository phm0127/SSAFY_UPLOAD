package com.ssafy.hrm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HrmBootRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(HrmBootRestApplication.class, args);
	}

}
