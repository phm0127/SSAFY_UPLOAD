import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class hw_algo0429_서울_11반_박형민 {
	static int answer,N;
	static Integer[] arr;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int TC = sc.nextInt();
		for(int test_case = 1 ; test_case<=TC;test_case++) {
			answer=0;
			N=sc.nextInt();
			arr = new Integer[N];
			for(int i=0;i<N;i++) {
				arr[i]=sc.nextInt();
			}
			
			Arrays.sort(arr,Comparator.reverseOrder());
			int index=0;
			while(true) {
				if(index>=N-2) {
					break;
				}
				answer+=arr[index];
				answer+=arr[index+1];
				index+=3;
			}
			for(int i=0;i<N%3;i++) {
				answer +=arr[N-1-i];
			}
			System.out.println("#"+test_case+" "+answer);
		}
	}

}
