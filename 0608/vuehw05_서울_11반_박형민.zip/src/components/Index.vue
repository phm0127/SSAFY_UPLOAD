<template>
   <div id="emp">
    <table style="width: 60%; border: 1px solid #f5f5f5; border-collapse: separate; ">
        <colgroup>

            <col style="width: 8%;  " />

            <col style="width: 8%;" />



        </colgroup>
        <tr>
            <td style="background-color: #4270c2; color: #f5f5f5; text-align:center; padding: 5px;">
                이름
            </td>
            <td style="padding: 5px 10px;">
                <input type="text" id="name" v-model="name">
            </td>
        </tr>
        <tr>
            <td style="background-color: #4270c2; color: #f5f5f5; text-align:center; padding: 5px;">
                이메일
            </td>
            <td style="padding: 5px 10px;">
                <input type="text" id="email" v-model="email">
            </td>
        </tr>
        <tr>
            <td style="background-color: #4270c2; color: #f5f5f5; text-align:center; padding: 5px;">
                고용일
            </td>
            <td style="padding: 5px 10px;">
                <input type="date" id="hiredate" v-model="hiredate">
            </td>
        </tr>
        <tr>
            <td style="background-color: #4270c2; color: #f5f5f5; text-align:center; padding: 5px;">
                관리자
            </td>
            <td style="padding: 5px 10px;">
                <select id="admin" v-model="admin" style="padding: 5px 10px;">
                    <option :value=adm.admin v-for="adm in admins" v-bind:key="adm">{{adm.showtext}}</option>
                </select>
            </td>
        </tr>
        <tr>
            <td style="background-color: #4270c2; color: #f5f5f5; text-align:center; padding: 5px;">
                직책
            </td>
            <td style="padding: 5px 10px;">
                <select id="position" v-model="position" style="padding: 5px 10px;">
                    <option :value=pos.position v-for="pos in positions" v-bind:key="pos">{{pos.position}}</option>
                </select>
            </td>
        </tr>
        <tr>
            <td style="background-color: #4270c2; color: #f5f5f5; text-align:center; padding: 5px;">
                부서
            </td>
            <td style="padding: 5px 10px;">
                <select id="depart" v-model="depart" style="padding: 5px 10px;">
                    <option :value=dep.depart v-for="dep in departs" v-bind:key="dep">{{dep.depart}}</option>
                </select>

            </td>
        </tr>
        <tr>
            <td style="background-color: #4270c2; color: #f5f5f5; text-align:center; padding: 5px;">
                월급
            </td>
            <td style="padding: 5px 10px;">
                <input type="number" id="salary" v-model="salary">
            </td>
        </tr>
        <tr>
            <td style="background-color: #4270c2; color: #f5f5f5; text-align:center; padding: 5px;">
                커미션
            </td>
            <td style="padding: 5px 10px;">
                <input type="number" id="commission" v-model="commission">
            </td>
        </tr>
    </table>
    <button id="addBtn" v-on:click="clickBtn()" style="display: table; margin : 10px auto;">사원 추가</button>

  </div>
</template>
<script>
    import axios from 'axios';
    
    export default {
        name:'Index',
        data : function() {

        return {
            name: '',
            email: '',
            hiredate: '',
            admin: false,
            admins: [
                {
                    admin: true,
                    showtext: "권한 있음"
                },
                {
                    admin: false,
                    showtext: "권한 없음"
                }
            ],
            position: '사장',
            positions: [
                {
                    position: '사장'
                },
                {
                    position: '기획부장'
                },
                {
                    position: '영업부장'
                },
                {
                    position: '총무부장'
                },

                {
                    position: '인사부장'
                },
                {
                    position: '과장'
                },
                {
                    position: '영업대표이사'
                },
                {
                    position: '사원'
                }
            ],
            depart: '기획부',
            departs: [
                {
                    depart: '기획부'
                },
                {
                    depart: '영업부'
                },
                {
                    depart: '총무부'
                },
                {
                    depart: '인사부'
                },
                {
                    depart: '기타'
                }
            ],
            salary: '',
            commission: ''
        };
    }//data
	
	
    , created() {
        




    }//created
    , methods : {
		clickBtn() {
        	console.log("hi");
            let employee = {name: this.name, email: this.email, hiredate: this.hiredate, admin: this.admin, position: this.position, depart: this.depart, salary: this.salary, commission: this.commission };
            console.log(this.name);
            axios({
                url: 'http://localhost:8080/vue/employee/',
                method: 'post',
                data:{
                	name: this.name, email: this.email, hiredate: this.hiredate, admin: this.admin, position: this.position, depart: this.depart, salary: this.salary, commission: this.commission
                }
            })//axios
                .then((response) => {
                    console.dir(response.data)
                   
                })//then
                .catch((error) => {
                    console.dir(error);
                });//catch
            console.log(employee);

        }
	}
};
    
</script>
<style>

</style>