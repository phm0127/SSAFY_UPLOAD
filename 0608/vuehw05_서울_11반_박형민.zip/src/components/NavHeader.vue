<template>
    <p>
      <router-link to="/">등록</router-link>
      <router-link to="/list">직원 목록</router-link>
    </p> 
</template>

<script>
    export default {
        name: 'NavHeader'
    }
</script>

<style>

</style>