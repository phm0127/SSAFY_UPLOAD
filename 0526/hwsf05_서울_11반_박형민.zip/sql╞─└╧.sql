use ssafyweb;
Drop table product;

create table product(
ID	varchar(20) not null primary key,
name varchar(20) default null,
price int default 0,
description varchar(100) default null
);

