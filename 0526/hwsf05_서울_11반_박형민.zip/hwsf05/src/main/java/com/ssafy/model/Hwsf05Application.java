package com.ssafy.model;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hwsf05Application {

	public static void main(String[] args) {
		SpringApplication.run(Hwsf05Application.class, args);
	}

}
