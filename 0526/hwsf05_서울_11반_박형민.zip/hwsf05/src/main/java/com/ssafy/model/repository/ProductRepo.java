package com.ssafy.model.repository;

import java.util.List;

import com.ssafy.model.dto.Product;


public interface ProductRepo {
	
	public List<Product> selectAll();
	public int insert(Product product);
	public Product selectOne(String id);
	public int modify(Product product);
	public int remove(Product product);
	
}
