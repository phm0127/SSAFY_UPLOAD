package com.ssafy.model.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.model.dto.Product;

@Repository
public class ProductRepoImpl implements ProductRepo{
	
	@Autowired
	SqlSession sqlsession;
	
	
	
	@Override
	public List<Product> selectAll() {
		List<Product> list;
		list=sqlsession.selectList("product.selectAll");
		
		return list;
	}
	
	
	@Override
	public Product selectOne(String id) {
		Product product;
		Map<String,String> map = new HashMap<String, String>();
		map.put("id",id);
		product=sqlsession.selectOne("product.selectOne",map);
		System.out.println("repo - product : "+product);
		return product;
	}

	

	@Override
	public int insert(Product product) {
		
		return sqlsession.insert("product.insert",product);
	}


	@Override
	public int modify(Product product) {
		return sqlsession.update("product.modify", product);
	}


	@Override
	public int remove(Product product) {
		return sqlsession.delete("product.delete",product);
	}
	
	

	
}
