package HW0203;

import java.util.Scanner;

public class StudentArrayTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int menuNo=0;
		while(true) {
			System.out.println("");
			System.out.print("0:Exit 1: input 2: output");
			menuNo=sc.nextInt();
			if(menuNo==0) {
				System.out.println("bye bye~~~"); break;
			}
			else if (menuNo==1) {
				
			}
			else {
				
			}
		}
	}

}
