package com.ssafy.model.service;

import java.util.List;

import javax.inject.Inject;

import com.ssafy.model.dto.Product;
import com.ssafy.model.repository.ProductRepo;

public interface ProductService {

	@Inject
	public ProductRepo getRepo();
	
	@Inject
	public List<Product> selectAll();
	
	@Inject
	public Product select(String id);
	
	@Inject
	public int insert(Product product);

	@Inject
	public int update(Product product);
	
	@Inject
	public int remove(String id);
}
