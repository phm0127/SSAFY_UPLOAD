package com.ssafy.test;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;
import com.ssafy.model.service.ProductServiceImpl;

public class BeanTest {
	
	
	/*
		제가 얇게나마 구글링을 해본 결과, static 함수인 main에서는 어노테이션을 통한 DI가 안되는 것 같습니다. (아닐 수도 있지만, 해결 방법을 찾지 못해 이렇게 제출합니다.)
	 */
	public static void main(String[] args) {
		ProductService service = new ProductServiceImpl();
		Product product = new Product();
		product.setID("ABC");
		product.setName("SSAFY");
		product.setPrice(100);
		product.setDescription("설명");
		service.insert(product);
		service.select("ABC").toString();
	}
	
}
