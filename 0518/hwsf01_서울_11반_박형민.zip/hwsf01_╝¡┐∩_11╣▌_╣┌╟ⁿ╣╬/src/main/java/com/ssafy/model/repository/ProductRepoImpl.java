package com.ssafy.model.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ssafy.model.dto.Product;

public class ProductRepoImpl implements ProductRepo{
	
	HashMap<String, Product> hash;
	public ProductRepoImpl() {
		hash = new HashMap<String, Product>();
	}
	
	@Override
	public List<Product> selectAll() {
		List<Product> list = new ArrayList<Product>();
		for(String s : hash.keySet()) {
			list.add(hash.get(s));
		}
		return list;
	}

	@Override
	public Product select(String id) {
		return hash.get(id);
	}

	@Override
	public int insert(Product product) {
		hash.put(product.getID(), product);
		return 0;
	}

	@Override
	public int update(Product product) {
		hash.put(product.getID(), product);
		return 0;
	}

	@Override
	public int remove(String id) {
		hash.remove(id);
		return 0;
	}
}
