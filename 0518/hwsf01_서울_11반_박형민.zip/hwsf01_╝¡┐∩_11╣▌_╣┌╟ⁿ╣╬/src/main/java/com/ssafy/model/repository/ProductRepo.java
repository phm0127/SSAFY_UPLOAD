package com.ssafy.model.repository;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Repository;

import com.ssafy.model.dto.Product;

@Repository
public interface ProductRepo {
	
	@Inject
	public List<Product> selectAll();
	
	@Inject
	public Product select(String id);
	
	@Inject
	public int insert(Product product);

	@Inject
	public int update(Product product);
	
	@Inject
	public int remove(String id);
	
}
