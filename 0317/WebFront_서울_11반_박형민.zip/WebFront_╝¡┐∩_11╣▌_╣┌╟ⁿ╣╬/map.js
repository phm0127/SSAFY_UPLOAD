/**
 * MyMap 생성자로 사용될 함수를 구현
 */
 MyMap = function(){
  this.map = new Object();
  this.count = new Number(0);
 };   
 MyMap.prototype = {

    put : function(key, value){   
         this.map[key] = value;
         this.count++;
     },

    get : function(key){   
         return this.map[key];
    },
    
    
    clear : function(){ 
    	this.count = 0;  
    	this.map=new Object();
    },

     remove : function(key){    
      delete this.map[key];
      this.count--;
    },
    
     size : function(){
       
       return this.count;
    }
 };

