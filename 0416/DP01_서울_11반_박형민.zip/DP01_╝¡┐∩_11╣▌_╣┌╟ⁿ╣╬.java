import java.util.Scanner;

public class DP01_서울_11반_박형민 {
	static int N;
	static int[] memo;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		memo = new int[N+1];
		memo[0]=0;
		memo[1]=1;
		memo[2]=2;
		memo[3]=4;
		/* memo[4]=7
		f(n) = f(n-3)+f(n-2)+f(n-1)
		f(n)의 이전 단계에서 하나의 막대만 사용해서 f(n)에 도달하는 방법은 f(n-3)에서 빨간색, f(n-2)에서 노란색, f(n-1)에서 파란색을 쓰는 경우
		 */
		System.out.println(gogosing(N));
		
	}
	
	public static int gogosing(int n) {
		if(memo[n]>0) {
			return memo[n];
		}
		if(n==0) {
			return 0;
		}
		memo[n]=gogosing(n-3)+gogosing(n-2)+gogosing(n-1);
		return memo[n];
	}

}
