import java.util.Scanner;

public class hwalgo0416_서울_11반_박형민 {
	static int N;
	static int[] score;
	static int[][] memo;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		score = new int[N+1];
		memo = new int[2][N+1];
		for(int i=1;i<=N;i++) {
			score[i] = sc.nextInt();
		}
		int answer = Math.max(dp(1,0),dp(2,0));
		System.out.println(answer);
	}
	
	public static int dp(int index,int state) {
		if(index>N) {
			return Integer.MIN_VALUE;
		}
		if(index==N) {
			return score[N];
		}
		if(memo[state][index]>0) {
			return memo[state][index];
		}
		
		if(state==1) {
			memo[state][index]=dp(index+2,0)+score[index];
			return memo[state][index];
		}
			
		memo[state][index]=Math.max(dp(index+1,1)+score[index], dp(index+2,0)+score[index]);
		return memo[state][index];
	}

}
