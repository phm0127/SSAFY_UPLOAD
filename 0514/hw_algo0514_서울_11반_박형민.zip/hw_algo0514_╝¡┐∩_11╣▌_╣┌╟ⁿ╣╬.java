import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class hw_algo0514_서울_11반_박형민 {
	static int N,answer;
	static int[][] map;
	static boolean[][] b;
	static int[] dR= {-1,1,0,0};
	static int[] dC= {0,0,-1,1};
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N =sc.nextInt();
		map=new int[N][N];
		for(int i=0;i<N;i++) {
			for(int j=0;j<N;j++) {
				map[i][j]=sc.nextInt();
			}
		}
		int max;
		for(int k=1;k<100;k++) {
			b=new boolean[N][N];
			max=0;
			for(int i=0;i<N;i++) {
				for(int j=0;j<N;j++) {
					if(map[i][j]>k&&!b[i][j]) {
						b[i][j]=true;
						cal(i,j,k);
						max++;
					}
				}
			}
			answer=Math.max(max, answer);
			if(max==0) break;
		}
		System.out.println(answer);
	}
	
	public static void cal(int tr, int tc,int k) {
		int nr,nc,r,c;
		Queue<RC> q = new LinkedList<RC>();
		q.add(new RC(tr,tc));
		while(!q.isEmpty()) {
			RC rc = q.poll();
			r=rc.r;
			c=rc.c;
			for(int i=0;i<4;i++) {
				nr=r+dR[i];
				nc=c+dC[i];
				if(nr>=0&&nr<N&&nc>=0&&nc<N&&!b[nr][nc]&&map[nr][nc]>k) {
					b[nr][nc]=true;
					q.add(new RC(nr,nc));
				}
			}
		}
	}

}
class RC{
	int r;
	int c;
	public RC(int r, int c) {
		this.r = r;
		this.c = c;
	}
	
}
