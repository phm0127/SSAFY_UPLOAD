import java.util.Scanner;

public class Main_1699 {
	static int N,answer;
	static int[] memo;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		memo = new int[N+1];
		for(int i =2;i<N+1;i++) {
			memo[i]=Integer.MAX_VALUE;
		}
		memo[0]=0;
		memo[1]=1;
		cal(N);
		
		System.out.println(memo[N]);
	}
	
	public static int cal(int n) {
		if(memo[n]!=Integer.MAX_VALUE) {
			return memo[n];
		}
		int i=1;
		while(true) {
			if(i*i>n) {
				break;
			}
			memo[n]=Math.min(memo[n], 1+cal(n-i*i));
			i++;
		}
		
		return memo[n];
	}

}
