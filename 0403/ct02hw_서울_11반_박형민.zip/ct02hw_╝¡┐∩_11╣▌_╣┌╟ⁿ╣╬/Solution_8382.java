import java.util.Scanner;

public class Solution_8382 {
	static int answer;
	static int x,y,ox,oy;
	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		int TC = sc.nextInt();
		for(int tese_case = 1; tese_case <= TC; tese_case++) {
			x=sc.nextInt();
			y=sc.nextInt();
			ox=sc.nextInt();
			oy=sc.nextInt();
			int intervalX=Math.abs(x-ox);
			int intervalY=Math.abs(y-oy);
			int min = Math.min(intervalX, intervalY);
			answer = 2*min;
			
			if(intervalX==min&&intervalY==min) {
				
			}else if(intervalX==min) {
				answer += 2*(intervalY-min);
				if((intervalY-min)%2==1) {
					answer-=1;
				}
			}else {
				answer += 2*(intervalX-min);
				if((intervalX-min)%2==1) {
					answer-=1;
				}
			}
		
			System.out.println("#"+tese_case+" "+answer);
		}
	}

}
