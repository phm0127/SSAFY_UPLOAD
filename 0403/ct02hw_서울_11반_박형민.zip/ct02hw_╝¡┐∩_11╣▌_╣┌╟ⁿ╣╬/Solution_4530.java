import java.util.Scanner;

public class Solution_4530 {
	static long start, end , answer;
	static long[] memo;
	public static void main(String[] args) {
		memo=new long[13];
		memo[1]=1;
		Scanner sc = new Scanner(System.in);
		int TC = sc.nextInt();
		for(int test_case = 1; test_case <=TC; test_case++) {
			
			start = sc.nextLong();
			end = sc.nextLong();
			if(start<0) {
				if(end<0) {
					answer = end - start;
					answer -= calFour(-start)-calFour(-end);
				}
				else {
					answer = end-start-1;
					answer -= calFour(-start)+calFour(end);
				}
			}
			else {
				answer = end-start;
				answer -= calFour(end)-calFour(start);
			}
			
			System.out.println("#"+test_case+" "+ answer);
		}
	}
	
	public static long calFour(long num){
		long fourCount=0;
		long tmp = num;
		int exponent=0;
		long ten=1;
		while(tmp>0) {
			tmp/=10;
			ten*=10;
			exponent++;
		}
		
		int front;
		long end;
		tmp=num;
		while(ten>0) {
			front=(int)(tmp/ten);
			end = tmp%ten;
			fourCount+=(getMemo(exponent))*front;
			if(front>=4) {
				fourCount-=(getMemo(exponent));
				fourCount+=ten;
			}
			exponent--;
			ten/=10;
			tmp=end;
		}
		
		
		return fourCount;
	}
	
	public static long getMemo(int exponent) {
		if(exponent==0) {
			return 0;
		}
		if(memo[exponent]>0) {
			return memo[exponent];
		}
		long ten=1;
		for(int i=0;i<exponent-1;i++) {
			ten*=10;
		}
		memo[exponent]=getMemo(exponent-1)*9+ten;
		return memo[exponent];
	}
	
	
	
	
	public static long brute(long num){
		long count =0;
		
		while(num>0) {
			long tmp=num;
			while(tmp>0) {
				if(tmp%10==4) {
					count++;
					break;
				}
				tmp/=10;
			}
			num--;
		}
		return count;
	}
}
