import java.util.Scanner;

public class Solution_9659 {
	static int N,M;
	static long[] memo;
	static int[][] tab;
	static long[] answer;
	static final long MODULE = 998244353;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int TC = sc.nextInt();
		for(int test_case = 1; test_case<=TC; test_case++) {
			N = sc.nextInt();
			memo = new long[N+1];
			memo[0]=1;
			tab=new int[N-1][3];
			for(int i=0; i<N-1;i++) {
				tab[i][0]=sc.nextInt();
				tab[i][1]=sc.nextInt();
				tab[i][2]=sc.nextInt();
			}
			M=sc.nextInt();
			answer = new long[M];
			System.out.print("#"+test_case);
			for(int i=0;i<M;i++) {
				answer[i] = sc.nextLong();
				memo[1]=answer[i];
				for(int j=0;j<N-1;j++) {
					if(tab[j][0]==1) {
						answer[i]=f1(tab[j][1],tab[j][2],j+2)%MODULE;
					}
					else if(tab[j][0]==2) {
						answer[i]=f2(tab[j][1],tab[j][2],j+2)%MODULE;
					}
					else if(tab[j][0]==3) {
						answer[i]=f3(tab[j][1],tab[j][2],j+2)%MODULE;
					}
				}
				System.out.print(" "+answer[i]);
			}
			
			System.out.println();
			
		
			
			
		}
	}
	
	public static long f1(int a,int b, int n) {
		long fx=0;
		fx=memo[a]+memo[b];
		
		memo[n]=fx%MODULE;
		return memo[n];
	}
	public static long f2(int a,int b, int n) {
		long fx=0;
		fx=a*memo[b];
		
		memo[n]=fx%MODULE;
		return memo[n];
	}
	public static long f3(int a,int b, int n) {
		long fx=0;
		fx=memo[a]*memo[b];
		
		memo[n]=fx%MODULE;
		return memo[n];
	}
	
	

}
