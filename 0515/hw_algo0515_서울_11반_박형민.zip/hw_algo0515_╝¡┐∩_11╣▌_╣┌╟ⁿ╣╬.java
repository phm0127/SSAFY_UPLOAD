import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class hw_algo0515_서울_11반_박형민 {
	static int R,C,baser=-1,basec;
	static int[][] map;
	static boolean[][] b;
	static int[] dR= {-1,1,0,0};
	static int[] dC= {0,0,-1,1};
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer token = new StringTokenizer(br.readLine()," ");
		R = Integer.parseInt(token.nextToken());
		C = Integer.parseInt(token.nextToken());
		map = new int[R][C];
		for(int i=0;i<R;i++) {
			token = new StringTokenizer(br.readLine()," ");
			for(int j=0;j<C;j++) {
				map[i][j]=Integer.parseInt(token.nextToken());
			}
		}
		Queue<Air> q = new LinkedList<Air>();
		Queue<Air> q2 = new LinkedList<Air>();
		for(int i=0;i<R;i++) {
			for(int j=0;j<C;j++) {
				if(map[i][j]==0) {
					if(i==0||i==R-1||j==0||j==C-1) {
						baser=i;
						basec=j;
						break;
					}
				}
			}
			if(baser>=0) break;
		}
		int r,c,nr,nc;
		int tmp=0;
		
		int count=0,cnt=0;
		int go = 0;
		boolean flag = true;
		q.add(new Air(baser,basec));
		b=new boolean[R][C];
		b[baser][basec]=true;
		while(flag) {
			while(!q.isEmpty()) {
				Air air = q.poll();
				r=air.r;
				c=air.c;
				map[r][c]=go-1;
				for(int i=0;i<4;i++) {
					nr=r+dR[i];
					nc=c+dC[i];
					if(nr>=0&&nr<R&&nc>=0&&nc<C) {
						if(map[nr][nc]==go&&!b[nr][nc]) {
							b[nr][nc]=true;
							q.add(new Air(nr,nc));
						}
						if(map[nr][nc]==0&&!b[nr][nc]) {
							b[nr][nc]=true;
							q.add(new Air(nr,nc));
						}
					}
				}
			}
			flag=false;
			for(int i=0;i<R;i++) {
				for(int j=0;j<C;j++) {
					if(map[i][j]==1) {
						for(int k=0;k<4;k++) {
							nr=i+dR[k];
							nc=j+dC[k];
							if(nr>=0&&nr<R&&nc>=0&&nc<C) {
								if(map[nr][nc]<0) {
									flag=true;
									
									q2.add(new Air(i,j));
									break;
								}
							}
						}
					}
				}
			}
			go--;
			if(!flag) break;
			tmp=q2.size();
			while(!q2.isEmpty()) {
				Air air = q2.poll();
				map[air.r][air.c]=go-1;
				q.add(air);
			}
			
			count++;
		}
		
		System.out.println(count);
		System.out.println(tmp);
	}

}
class Air{
	int r;
	int c;
	public Air(int r, int c) {
		this.r = r;
		this.c = c;
	}
	
}