package app;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import person.Patient;

public class NetworkHttpServerPatient {
	
	public static void main(String[] args) throws IOException {

		Patient p1 = new Patient("박형민", 27, "010-1111-1111", "두통", "001", false);
		Patient p2 = new Patient("김구라", 27, "010-2222-2222", "치통", "002", true);
		Patient p3 = new Patient("이누구", 25, "010-3333-3333", "복통", "003", true);
		Patient p4 = new Patient("사아피", 29, "010-4444-4444", "데통", "004", false);
		Patient p5 = new Patient("이름길다", 29, "010-4444-4444", "데통", "004", false);
		
		// 병원 Collection
		List<Patient> patientList = new ArrayList<Patient>();
		patientList.add(p1);
		patientList.add(p2);
		patientList.add(p3);
		patientList.add(p4);
		patientList.add(p5);
				
		StringBuilder sb = new StringBuilder();
		sb.append("<html><body><h2>환자 정보</h2><table style='border: 2px solid blue;'> \n");
		for( Patient p : patientList ) {
			StringBuilder name = new StringBuilder(p.getName());
			for(int i=1;i<name.length();i++) {
				name.setCharAt(i, 'X');
			}
			StringBuilder phone = new StringBuilder(p.getPhone());
			for(int i=phone.lastIndexOf("-")+1;i<phone.length();i++) {
				phone.setCharAt(i, 'X');
			}
			sb.append("<tr style= 'border: 1px solid green;'> ");
			sb.append("<td>"+name+"</td>");
			sb.append("<td>"+phone+"</td></tr>");
		}
		sb.append("</table></body></html>");
		String html = sb.toString();
		
		try (ServerSocket ss = new ServerSocket(8091)) {
			System.out.println("[Hospital Info Server is ready]");
			
			while (true) {
				try ( Socket socket = ss.accept() ) {

					BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"));

					bw.write("HTTP/1.1 200 OK \r\n");
					bw.write("Content-Type: text/html;charset=utf-8\r\n");
					bw.write("Content-Length: " + html.length() + "\r\n");
					bw.write("\r\n");
					bw.write(html);
					bw.write("\r\n");
	                bw.flush();

				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
