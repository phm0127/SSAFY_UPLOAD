package com.ssafy.model.controller;

import org.springframework.ui.Model;

import com.ssafy.model.dto.Product;

public interface ProductController {
	public String write(Product product);
	
	public String writeForm();

	public String showList(Model m);
}
