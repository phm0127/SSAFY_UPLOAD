import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Main_1197 {
	static int[] parents;
	static int[] rank;
	public static void main(String[] args) {
		int result=0;
		Scanner sc = new Scanner(System.in);
		int V = sc.nextInt();
		int E = sc.nextInt();
		int[][] edges = new int[E][3];
		parents=new int[V];
		rank = new int[V];
		for(int i =0;i<E;i++) {
			edges[i][0] = sc.nextInt()-1;
			edges[i][1] = sc.nextInt()-1;
			edges[i][2] = sc.nextInt();
		}
		Arrays.sort(edges, new Comparator<int[]>() {

			@Override
			public int compare(int[] o1, int[] o2) {
				return Integer.compare(o1[2], o2[2]);
			}
		});
		for(int i=0;i<V;i++) {
			makeSet(i);
		}
		int cnt=0;
		for(int i = 0; i< E;i++) {
			int a=findSet(edges[i][0]);
			int b=findSet(edges[i][1]);
			if(a==b) continue;
			union(a,b);
			result+= edges[i][2];
			cnt++;
			if(cnt==V-1)break;
		}
		System.out.println(result);
	}
	
	static void makeSet(int x) {
		parents[x] = x;
	}
	
	static int findSet(int x) {
		if(x==parents[x]) {
			return x;
		}else {
			return findSet(parents[x]);
		}
	}
	static void union(int x,int y) {
		int px = findSet(x);
		int py = findSet(y);
		if(rank[px]>rank[py]) {
			parents[py]=px;
		}else {
			parents[px]=py;
			if(rank[px]==rank[py]) {
				rank[py]++;
			}
		}
	}
}