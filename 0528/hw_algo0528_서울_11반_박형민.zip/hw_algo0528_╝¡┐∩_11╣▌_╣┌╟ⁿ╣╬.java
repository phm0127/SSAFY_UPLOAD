import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.Set;

public class hw_algo0528_서울_11반_박형민 {
	static int N,M,answer,R,C,L;
	static int[][] map;
	static boolean[][] visit;
	static int[] dR= {-1,1,0,0};
	static int[] dC= {0,0,-1,1};
	static List<Integer>[] list;

	public enum road{
		TOP(1,2,5,6)
		,LEFT(1,3,4,5)
		,RIGHT(1,3,6,7)
		,BOTTOM(1,2,4,7) ;
		Set<Integer> set;
		road(int link1, int link2, int link3, int link4) {
			set = new HashSet<>();
			set.add(link1);
			set.add(link2);
			set.add(link3);
			set.add(link4);
		}
		public boolean contains(int param) {
			if(set.contains(param)) {
				return true;
			}
			return false;
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int TC = sc.nextInt();
		list = new List[8];
		for(int i=1;i<8;i++) {
			list[i]=new ArrayList<>();
			if(road.TOP.contains(i)) {
				list[i].add(1);
			}
			if(road.BOTTOM.contains(i)) {
				list[i].add(0);
			}
			if(road.LEFT.contains(i)) {
				list[i].add(3);
			}
			if(road.RIGHT.contains(i)) {
				list[i].add(2);
			}
		}
		
		for(int test_case=1; test_case<=TC;test_case++) {
			answer=0;
			N=sc.nextInt();
			M=sc.nextInt();
			R=sc.nextInt();
			C=sc.nextInt();
			L=sc.nextInt();
			map=new int[N][M];
			visit=new boolean[N][M];
			for(int i=0;i<N;i++) {
				for(int j=0;j<M;j++) {
					map[i][j]=sc.nextInt();
				}
			}
			Queue<Location> q = new LinkedList<Location>();
			visit[R][C]=true;
			q.add(new Location(R, C));
			while(!q.isEmpty()&&L>0) {
				int size = q.size();
				for(int turn =0;turn<size;turn++) {
					Location loc = q.poll();
					int r = loc.r;
					int c = loc.c;
					answer++;
					for(int i:list[map[r][c]]) {
						road route;
						int nr= r+dR[i];
						int nc= c+dC[i];
						if(nr>=0&&nr<N&&nc>=0&&nc<M) {
							if(i==0) route=road.TOP;
							else if(i==1) route=road.BOTTOM;
							else if(i==2) route=road.LEFT;
							else route=road.RIGHT;
							if(!visit[nr][nc]&&route.contains(map[nr][nc])) {
								visit[nr][nc]=true;
								q.add(new Location(nr, nc));
							}
						}
					}
				}
				L--;
			}
			
			System.out.println("#"+test_case+" "+answer);
		}
	}

}
class Location{
	int r;
	int c;
	public Location(int r, int c) {
		this.r=r;
		this.c=c;

	}
}
