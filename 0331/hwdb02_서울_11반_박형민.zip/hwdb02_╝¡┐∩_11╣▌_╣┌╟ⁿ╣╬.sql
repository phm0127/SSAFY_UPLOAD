-- create database ssafy_product;
-- use ssafy_product;
create table product(
	no varchar(10),
    name varchar(20),
    price int
);

insert into product (no, name, price) values
('SSAFY01','펭수 노트북',2000000),
('SSAFY02','삼성 노트북',1000000),
('SSAFY03','싸피 노트북',3000000),
('SSAFY11','펭수 TV',4000000),
('SSAFY12','삼성 TV',3000000),
('SSAFY13','싸피 TV',5000000);


select no as '상품 코드', name as 상품명, round(price*0.85) as '세일 가격' from product;

update product set price = round(price*0.8) where name like '%TV%';

select sum(price) as '총 금액' from product;