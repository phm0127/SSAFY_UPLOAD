import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}//static

	private String url = "jdbc:mysql://127.0.0.1:3306/ssafy_product?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
	private String user = "ssafy";
	private String password = "ssafy";
	private Connection getConnection() throws SQLException {
		Connection con = DriverManager.getConnection(url, user, password);
		return con;
	}
	
	public void insertProduct(String no, String name, int price) {
		
		String sql = "insert into product (no, name, price) values(?, ?, ?)";
		PreparedStatement psmt = null;
		Connection con = null;
		try {
			con = getConnection();
			psmt = con.prepareStatement(sql);
			psmt.setString(1, no);
			psmt.setString(2, name);
			psmt.setInt(3, price);
			psmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(psmt != null) psmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public List<Product> viewAllProduct(){
		ArrayList<Product> list = new ArrayList<>();
		String sql = "select no, name, price from product";
		Connection con = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		try {
			con = getConnection();
			psmt = con.prepareStatement(sql);
			rs = psmt.executeQuery();
			while (rs.next()) {
				list.add(new Product(rs.getString("no"),rs.getString("name"),rs.getInt("price")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(psmt != null) psmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public Product searchProductByNo(String no) {
		String sql = "select no, name, price from product where no = ?";
		Connection con = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		Product ret = null;
		try {
			con = getConnection();
			psmt = con.prepareStatement(sql);
			psmt.setString(1, no);
			rs = psmt.executeQuery();
			while (rs.next()) {
				ret = new Product(rs.getString("no"),rs.getString("name"),rs.getInt("price"));
				break;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(psmt != null) psmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return ret;
	}
	
	
	public void updateProduct(String no, String name, int price) {
		
		String sql = "update product set name = ?, price = ? where no = ?";
		PreparedStatement psmt = null;
		Connection con = null;
		try {
			con = getConnection();
			psmt = con.prepareStatement(sql);
			psmt.setString(1, name);
			psmt.setInt(2, price);
			psmt.setString(3, no);
			psmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(psmt != null) psmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void deleteProductByNo(String no) {
		String sql = "delete from product where no = ?";
		Connection con = null;
		PreparedStatement psmt = null;
		try {
			con = getConnection();
			psmt = con.prepareStatement(sql);
			psmt.setString(1, no);
			psmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(psmt != null) psmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void removeAll() {
		String sql = "truncate product";
		Connection con = null;
		PreparedStatement psmt = null;
		try {
			con = getConnection();
			psmt = con.prepareStatement(sql);
			psmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(psmt != null) psmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
