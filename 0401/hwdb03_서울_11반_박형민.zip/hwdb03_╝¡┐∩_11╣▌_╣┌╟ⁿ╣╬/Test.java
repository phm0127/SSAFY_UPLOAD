import java.util.List;

public class Test {

	public static void main(String[] args) {
		ProductDAO pdao = new ProductDAO();
		pdao.removeAll();
		pdao.insertProduct("1", "SSAFY 노트북", 100);
		pdao.insertProduct("2", "펭수 노트북", 200);
		pdao.insertProduct("3", "PRO TV", 300);
		pdao.insertProduct("4", "멀티캠퍼스 TV", 200);
		List<Product> list = pdao.viewAllProduct();
		for(Product p : list) {
			System.out.println(p);
		}
		pdao.deleteProductByNo("2");
		list = pdao.viewAllProduct();
		System.out.println("------------------------");
		for(Product p : list) {
			System.out.println(p);
		}
		
		// No=1인 제품을 출력
		System.out.println(pdao.searchProductByNo("1"));
		// 삭제한 2를 출력
		System.out.println(pdao.searchProductByNo("2"));
		
		// no=1 인 제품의 이름을 "수정한  노트북"으로 변경하고 가격을 200으로 변경함.
		pdao.updateProduct("1", "수정한 노트북", 200);
		System.out.println(pdao.searchProductByNo("1"));
		
	}

}
