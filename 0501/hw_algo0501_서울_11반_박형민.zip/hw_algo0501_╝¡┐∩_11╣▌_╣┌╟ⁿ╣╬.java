import java.util.HashSet;
import java.util.Scanner;

public class hw_algo0501_서울_11반_박형민 {
	static String s2,s3;
	static int answer;
	static HashSet<Integer> set;
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int TC = sc.nextInt();
		for(int test_case=1;test_case<=TC;test_case++) {
			set = new HashSet<>();
			s2 = sc.next();
			s3 = sc.next();
			cal2();
			answer = cal3();
			System.out.println("#"+test_case+" "+answer);
		}
	}
	static int cal3() {
		int[] arr = new int[s3.length()];
		for(int i=0;i<s3.length();i++) {
			arr[i]=s3.charAt(i)-'0';
		}
		for(int i=0;i<s2.length();i++) {
			if(arr[i]==0) {
				arr[i]=1;
				int exp=1;
				int sum=0;
				for(int j=s3.length()-1;j>=0;j--) {
					sum+=exp*arr[j];
					exp*=3;
				}
				if(set.contains(sum)) {
					return sum;
				}
				exp=1;
				sum=0;
				arr[i]=2;
				for(int j=s3.length()-1;j>=0;j--) {
					sum+=exp*arr[j];
					exp*=3;
				}
				if(set.contains(sum)) {
					return sum;
				}
				arr[i]=0;
			}
			else if(arr[i]==1) {
				arr[i]=0;
				int exp=1;
				int sum=0;
				for(int j=s3.length()-1;j>=0;j--) {
					sum+=exp*arr[j];
					exp*=3;
				}
				if(set.contains(sum)) {
					return sum;
				}
				exp=1;
				sum=0;
				arr[i]=2;
				for(int j=s3.length()-1;j>=0;j--) {
					sum+=exp*arr[j];
					exp*=3;
				}
				if(set.contains(sum)) {
					return sum;
				}
				arr[i]=1;
			}
			else if(arr[i]==2) {
				arr[i]=0;
				int exp=1;
				int sum=0;
				for(int j=s3.length()-1;j>=0;j--) {
					sum+=exp*arr[j];
					exp*=3;
				}
				if(set.contains(sum)) {
					return sum;
				}
				exp=1;
				sum=0;
				arr[i]=1;
				for(int j=s3.length()-1;j>=0;j--) {
					sum+=exp*arr[j];
					exp*=3;
				}
				if(set.contains(sum)) {
					return sum;
				}
				arr[i]=2;
			}
			
			
		}
		return -1;
	}
	
	
	static void cal2() {
		int[] arr = new int[s2.length()];
		for(int i=0;i<s2.length();i++) {
			arr[i]=s2.charAt(i)-'0';
		}
		for(int i=0;i<s2.length();i++) {
			if(arr[i]==0) {
				arr[i]=1;
				int exp=1;
				int sum=0;
				for(int j=s2.length()-1;j>=0;j--) {
					sum+=exp*arr[j];
					exp*=2;
				}
				set.add(sum);
				arr[i]=0;
			}
			else if(arr[i]==1) {
				arr[i]=0;
				int exp=1;
				int sum=0;
				for(int j=s2.length()-1;j>=0;j--) {
					sum+=exp*arr[j];
					exp*=2;
				}
				set.add(sum);
				arr[i]=1;
			}
			
			
		}
		
	}

}
