package com.ssafy.model.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;

@Controller
@RequestMapping(value="/product")
public class ProductControllerImpl implements ProductController {

	@Autowired
	ProductService service;
	
	@Override
	@RequestMapping(value="/write",method=RequestMethod.POST)
	public String write(Product product) {
		System.out.println(product.getId());
		service.insert(product);
		return form();
	}

	@Override
	@RequestMapping(value="/write",method=RequestMethod.GET)
	public String writeForm() {
		
		return "productwrite";
	}
	
	@Override
	@RequestMapping(value="/list",method=RequestMethod.GET)
	public @ResponseBody List<Product> showList() {
		System.out.println(service.selectAll().size());
		return service.selectAll();
	}
	
	@RequestMapping(value="/form",method=RequestMethod.GET)
	public String form() {
		
		return "productform";
	}

	@RequestMapping(value="/get/{id}",method=RequestMethod.GET)
	public @ResponseBody Product get(@PathVariable("id") String id) {
		System.out.println(id);
		return service.selectOne(id);
	}
	
	
	
	@RequestMapping(value="/modify",method=RequestMethod.POST)
	public String modify(Product product) {
		service.modify(product);
		System.out.println(product.getName());
		return form();
	}
	
	@RequestMapping(value="/remove",method=RequestMethod.POST)
	public String delete(Product product) {
		service.remove(product);
		System.out.println(product.getName());
		return form();
	}

}
