package com.ssafy.model.controller;

import java.util.List;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ssafy.model.dto.Product;

public interface ProductController {
	public String write(Product product);
	
	public String writeForm();

	public List<Product> showList();
	
	
}
