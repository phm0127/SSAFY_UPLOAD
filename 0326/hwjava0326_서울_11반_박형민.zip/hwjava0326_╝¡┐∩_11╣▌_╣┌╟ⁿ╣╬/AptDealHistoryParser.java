package xml;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class AptDealHistoryParser {

	public static void main(String[] args) {
		String aptName;
		File file = new File("./src/xml/AptDealHistory.xml");
	    SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
	    //
	    // 검색할 아파트명 설정하기.
	    aptName="아";
	    //
	    //
	    try {
	        SAXParser saxParser = saxParserFactory.newSAXParser();
	        AptSaxHandler handler = new AptSaxHandler();
	        saxParser.parse(file, handler);

	        List<Apt> aptList = handler.getAptList();
	        
	        for(Apt apt : aptList) {
	        	
	        	if(apt.getApt().contains(aptName)) {
	        		System.out.println(apt);
	        	}
	        	
	        	
	        }
	    } catch (ParserConfigurationException | SAXException | IOException e) {
	        e.printStackTrace();
	    }
		
	}

}


//////////////////////////////////////////////////////////////////////////////////
/*

 */
//////////////////////////////////////////////////////////////////////////////////

class AptSaxHandler extends DefaultHandler {
	
	final String PRICE = "거래금액";
	final String YEAR_OF_BUILT = "건축년도";
	final String YEAR="년";
	final String DONG= "법정동";
	final String APT= "아파트";
	final String MONTH= "월";
	final String DAY= "일";
	final String SQUARE= "전용면적";
	final String ZIP_CODE= "지번";
	final String LOCAL_CODE= "지역코드";
	final String FLOOR= "층";

	private List<Apt> aptList = new ArrayList<Apt>();
	private Apt apart = null;
	private StringBuilder data = null;

	public List<Apt> getAptList() {
		return aptList;
	}
	
	boolean bPrice = false;
	boolean bBuilt = false;
	boolean bYear = false;
	boolean bDong = false;
	boolean bApt = false;
	boolean bMonth = false;
	boolean bDay = false;
	boolean bSquare = false;
	boolean bZipCode = false;
	boolean bLocalCode = false;
	boolean bFloor = false;

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attr) throws SAXException {

		if (qName.equalsIgnoreCase("item")) {
			
			String price = attr.getValue(PRICE);

			apart = new Apt();
			

		}else if (qName.equalsIgnoreCase(PRICE)) {
			// set boolean values for fields, will be used in setting Employee variables
			bPrice = true;
		}
		else if (qName.equalsIgnoreCase(YEAR_OF_BUILT)) {
			// set boolean values for fields, will be used in setting Employee variables
			bBuilt = true;
		} else if (qName.equalsIgnoreCase(YEAR)) {
			bYear = true;
		} else if (qName.equalsIgnoreCase(DONG)) {
			bDong = true;
		} else if (qName.equalsIgnoreCase(APT)) {
			bApt = true;
		}else if (qName.equalsIgnoreCase(MONTH)) {
			bMonth = true;
		}else if (qName.equalsIgnoreCase(DAY)) {
			bDay = true;
		}else if (qName.equalsIgnoreCase(SQUARE)) {
			bSquare = true;
		}else if (qName.equalsIgnoreCase(ZIP_CODE)) {
			bZipCode = true;
		}
		else if (qName.equalsIgnoreCase(LOCAL_CODE)) {
			bLocalCode = true;
		}
		else if (qName.equalsIgnoreCase(FLOOR)) {
			bFloor = true;
		}
		
		// create the data container
		data = new StringBuilder();
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if (bPrice) {
			// age element, set Employee age
			apart.setPrice(data.toString());
			bPrice = false;
		} 
		else if (bBuilt) {
			// age element, set Employee age
			apart.setYearOfBuilt(data.toString());
			bBuilt = false;
		} else if (bYear) {
			apart.setYear(data.toString());
			bYear = false;
		} else if (bDong) {
			apart.setDong(data.toString());
			bDong = false;
		} else if (bApt) {
			apart.setApt(data.toString());
			bApt = false;
		} else if (bMonth) {
			apart.setMonth(data.toString());
			bMonth = false;
		} else if (bDay) {
			apart.setDay(data.toString());
			bDay = false;
		} else if (bSquare) {
			apart.setSquare(data.toString());
			bSquare = false;
		} else if (bZipCode) {
			apart.setZipCode(data.toString());
			bZipCode = false;
		} else if (bLocalCode) {
			apart.setLocalCode(data.toString());
			bLocalCode = false;
		} else if (bFloor) {
			apart.setFloor(data.toString());
			bFloor = false;
		}
		
		if (qName.equalsIgnoreCase("item")) {
			// add Employee object to list
			aptList.add(apart);
		}
	}

	@Override
	public void characters(char ch[], int start, int length) throws SAXException {
		data.append(new String(ch, start, length));
	}
}



//////////////////////////////////////////////////////////////////////////////////
/*

*/
//////////////////////////////////////////////////////////////////////////////////


class Apt {
	//
	
	//
	private String price ;
	private String yearOfBuilt ;
	private String year;
	private String dong;
	private String apt;
	private String month;
	private String day;
	private String square;
	private String zipCode;
	private String localCode;
	private String floor;
    
	
    
    
    public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getYearOfBuilt() {
		return yearOfBuilt;
	}
	public void setYearOfBuilt(String yearOfBuilt) {
		this.yearOfBuilt = yearOfBuilt;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getDong() {
		return dong;
	}
	public void setDong(String dong) {
		this.dong = dong;
	}
	public String getApt() {
		return apt;
	}
	public void setApt(String apt) {
		this.apt = apt;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getSquare() {
		return square;
	}
	public void setSquare(String square) {
		this.square = square;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getLocalCode() {
		return localCode;
	}
	public void setLocalCode(String localCode) {
		this.localCode = localCode;
	}
	public String getFloor() {
		return floor;
	}
	public void setFloor(String floor) {
		this.floor = floor;
	}

	@Override
    public String toString() {
    	StringBuilder builder = new StringBuilder();
		builder.append("아파트 명 : ");
		builder.append(apt);
		builder.append(", 법정동 : ");
		builder.append(dong);
		builder.append(", 거래 금액 : ");
		builder.append(price);

		return builder.toString();
    }
    
}



