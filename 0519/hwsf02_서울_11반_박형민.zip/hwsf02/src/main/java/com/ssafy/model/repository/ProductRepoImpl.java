package com.ssafy.model.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.model.dto.Product;

@Repository
public class ProductRepoImpl implements ProductRepo{
	
	@Autowired
	SqlSession sqlsession;
	
	
	
	@Override
	public List<Product> selectAll() {
		List<Product> list;
		list=sqlsession.selectList("product.selectAll");
		
		return list;
	}

	

	@Override
	public int insert(Product product) {
		
		return sqlsession.insert("product.insert",product);
	}

	
}
