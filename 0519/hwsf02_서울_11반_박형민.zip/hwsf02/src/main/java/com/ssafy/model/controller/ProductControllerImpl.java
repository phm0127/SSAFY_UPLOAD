package com.ssafy.model.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;

@Controller
@RequestMapping(value="/product")
public class ProductControllerImpl implements ProductController {

	@Autowired
	ProductService service;
	
	@Override
	@RequestMapping(value="/write",method=RequestMethod.POST)
	public String write(Product product) {
		System.out.println(product.getId());
		service.insert(product);
		return "redirect:/product/list";
	}

	@Override
	@RequestMapping(value="/write",method=RequestMethod.GET)
	public String writeForm() {
		
		return "productwrite";
	}
	
	@Override
	@RequestMapping(value="/list",method=RequestMethod.GET)
	public String showList(Model m) {
		
		m.addAttribute("list",service.selectAll());
		return "productlist";
	}


}
